import "./app-bar.js";
import "./note-item.js";
import "./input-note.js";
import "./loading.js";
import "../src/data/API/note-api.js";
