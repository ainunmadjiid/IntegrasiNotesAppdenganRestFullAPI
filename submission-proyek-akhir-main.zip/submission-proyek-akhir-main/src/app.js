import './styles/style.css';
import './components/index.js';
import notesData from './data/notes.js';

const baseUrl = 'https://notes-api.dicoding.dev/v2';

const getNote = () => {
  fetch(`${baseUrl}/notes`)
  .then(response => {
    return response.json();
  })
  .then(responseJson => {
    if (responseJson.error) {
      showResponseMessage(responseJson.message);
    } else {
      renderAllNotes(responseJson.notes);
    }
  })
  .catch(error => {
    showResponseMessage(error);
  });
}

const addNote = (note) => {
  fetch(`${baseUrl}/notes`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-Auth-Token': '12345'
    },
    body: JSON.stringify({ title: note.title, body: note.body })
  }).then(response => {
    return response.json();
  }).then(responseJson => {
    showResponseMessage(responseJson.message);
    if (!responseJson.error) {
      getNote();
    }
  }).catch(error => {
    showResponseMessage(error);
  })
}

const removeNote = (noteId) => {
  fetch(`${baseUrl}/notes/${noteId}`, {
    method: 'DELETE',
  }).then(response => {
    return response.json();
  }).then(responseJson => {
    showResponseMessage(responseJson.message);
    getNote();
  }).catch(error => {
    showResponseMessage(error);
  });
}
 

const renderAllNotes = (notes) => {
  const noteItems = document.querySelectorAll('note-item');

  noteItems.forEach(noteItem => {

    const shadowRoot = noteItem.shadowRoot;
    const titleElement = shadowRoot.querySelector('.note-title');
    const bodyElement = shadowRoot.querySelector('.note-description');
    const deleteButton = shadowRoot.querySelector('.button-delete');

    noteItem.note = notes;

    if (titleElement) {
      titleElement.textContent = note.title;
    }

    if (bodyElement) {
      bodyElement.textContent = note.body;
    }

    if (deleteButton) {
      deleteButton.addEventListener('click', () => {
        removeNote(note.id);
      });
    }
  });
};

const showResponseMessage = (message = 'Check your internet connection') => {
  alert(message);
};

document.addEventListener('DOMContentLoaded', () => {
  getNote();

  const inputNoteElement = document.querySelector('input-note');
  if (inputNoteElement) {
    inputNoteElement.addEventListener('note-added', event => {
      const newNote = event.detail;
      addNote(newNote);
    });
  }
});

